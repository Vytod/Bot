// SC BY © Vy CHAN
// RECODE WAJIB KASI CREDITS 
// WA: 087711376138
// TOKO KEBUTUHAN BOT TERPERCAYA
// HANYA DI SINI
import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'
const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)

// Owner
global.owner = [
['6287711376138', 'Vy', true],
['6287711376138', 'Vy', true],
]
global.mods = []
global.prems = []
// Info
global.nomorwa = '6287711376138'
global.packname = 'Made With'
global.author = '© Vytod!!'
global.namebot = 'Vytod!!'
global.wm = '© Vytod!!'
global.stickpack = 'Made With'
global.stickauth = '© Vytod!!'
global.fotonya = 'https://telegra.ph/file/45fa8ca4093fbb2a645eb.jpg'
// Payment
global.gopay = '087711376138'
global.dana = '087711376138'
// Info Wait
global.alya = 'Mwuhehe'
global.wait = '_Sedang Di Proses, Mohon Tunggu_....'
global.eror = 'Terjadi Kesalahan Coba Lagi Nanti!'
global.multiplier = 69 
// Apikey
global.APIs = {
    anu : 'anu.tv'
}

/*Apikey*/
global.APIKeys = {
    "anu.tv": "anu",
}

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  import(`${file}?update=${Date.now()}`)
})